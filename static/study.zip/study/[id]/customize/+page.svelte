<script lang='ts'>
	export let data;
	import { onMount } from 'svelte';
	import CircularProgress from '@smui/circular-progress';
	import { card_front, card_back, card_color, card_image, card_citation, segments, segment, customization_input, card_title, card_description, card_summary, card_third, card_evidence, customization_first_line, customization_second_line, customization_summary, customization_original_input } from '$lib/store.js';
	import { card_data } from '$lib/data_study.js';

    const identifier = data.id;

    $: paper_id = parseInt(identifier);
	
	$: card_htmlized = generateHTML($card_third.length != 0 ? $card_third[thirdIndex-1] : "");

	const baseURL = "https://35.90.86.195.nip.io" //"http://0.0.0.0:8000"

    let thirdIndex = 0;

	let isThirdLoading = false;

	const customizationInput = (input) => {

		isThirdLoading = true;
		
		fetch(`${baseURL}/card_customize` + '?' + new URLSearchParams({
			title: card_data[paper_id-1]["title"],
			description: card_data[paper_id-1]["description"],
			paper_summary: `${card_data[paper_id-1]["summary_1"]} ${card_data[paper_id-1]["summary_2"]}`,
			context: input
		}), {
			method: 'POST'
		})
		.then(result => {
			return result.json();
		}).then(res => {
			console.log(res);
			
			$card_third.push(res["card_third"]);
			$card_third = $card_third;
			$customization_first_line.push(res["first_line"]);
			$customization_first_line = $customization_first_line;
			$customization_second_line.push(res["second_line"]);
			$customization_second_line = $customization_second_line;
			$customization_summary.push(res["customization_summary"]);
			$customization_summary = $customization_summary;
			$customization_original_input.push(input);
			$customization_original_input = $customization_original_input;

            thirdIndex += 1;
			isThirdLoading = false;

            setTimeout(() => {

                const goodButton = document.getElementById("good");
                const badButton = document.getElementById("bad");

                if (goodButton != null && badButton != null) {
                    goodButton.onclick = () => {
                        badButton.style.backgroundColor = "transparent";
                        goodButton.style.backgroundColor = "rgb(219 234 254)";
                    };
                    badButton.onclick = () => {
                        goodButton.style.backgroundColor = "transparent";
                        badButton.style.backgroundColor = "rgb(254 226 226)";
                    };
                }
                }, 1000);
		})
	};


	function generateHTML(third) {
		return `
		<!DOCTYPE html>
		<html>
		<body>
			<div style="display: flex; flex-wrap: wrap; gap: 1rem;">
				<div class="card-front">
                    <div class="card-front-text">
                        <div class="vertical-middle">
                            <h3 class="title">
                                ${card_data[paper_id-1]["title"]}
                            </h3>
                            <p class="description">
                                ${card_data[paper_id-1]["description"]}
                            </p>
                        </div>
                    </div>
                    <div class="card-front-image">
                        <img class="image" src='https://paper2card.com/preloaded_images/${paper_id}.png'>
                    </div>
                </div>
				<div class="card-back">
                    <div class="summary-container">
                    <div class="vertical-middle">
                        <p class="summary-header">
                        About this paper
                        </p>
                        <p class="summary">
                            ${card_data[paper_id-1]["summary_1"]}<br><br>${card_data[paper_id-1]["summary_2"]}
                        </p>
                    </div>
                    </div>
                    <div class="evidence-container">
                    <div class="vertical-middle">
                        <p class="evidence-header">
                        Which part of the paper did the design guideline come from?
                        </p>
                        <p class="evidence">
                            ${card_data[paper_id-1]["evidence"]}
                        </p>
                    </div>
                    </div>
                    <div class="citation-container">
                    <div class="vertical-middle">
                        <p class="citation">
                            ${card_data[paper_id-1]["citation"]}
                        </p>
                    </div>
                    </div>
                </div>
				${third}
			</div>
		</body>
		</html>
		<style>
    @import url("https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap");

    .card-front {
        font-family: "Inter", sans-serif;
        box-shadow: 0 1px 2px rgb(0 0 0 / 7%), 0 2px 4px rgb(0 0 0 / 7%),
            0 4px 8px rgb(0 0 0 / 7%), 0 8px 16px rgb(0 0 0 / 7%),
            0 16px 32px rgb(0 0 0 / 7%), 0 32px 64px rgb(0 0 0 / 7%);
        width: 300px !important;
        height: 500px !important;
        margin-left: auto;
        margin-right: auto;
        line-height: 1 !important;
    }

    .card-front-text {
        height: 200px !important;
        background-color: ${card_data[paper_id-1]["color"]};
        display: table;
    }

    .card-front-image {
        height: 300px !important;
    }

    .summary-container {
        flex-grow: 1;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .summary-header {
        padding: 0 15px;
        font-size: 14px !important;
        font-weight: 600;
        color: #000000;
    }

    .summary {
        padding: 0 15px;
        margin-top: 10px !important;
        color: #000000;
        font-size: 13px !important;
        font-weight: 200;
        line-height: 18px;
    }

    .motive-container {
        display: table;
        width: auto;
        margin: 5px 20px;
        padding: 4px 8px;
        color: #000000;
        background-color: #EFEFEF;
    }
    .motive-container:first-of-type {
        margin: 0 20px 5px 20px !important;
    }
    .motive-container:hover {
        cursor: pointer;
        background-color: #DDDDDD;
    }
    .highlight-design-guideline {
        display: inline;
        background: #ffe53690;
        box-shadow: 0 0 0 #ffe53690, 0 0 0 #ffe53690;
        color: #000;
    }
    .highlight-persona {
        display: inline;
        background: #ffe536;
        box-shadow: 0 0 0 #ffe536, 0 0 0 #ffe536;
    }

    .badge {
        position:relative;
    }
    .badge[data-badge]:after {
        content:attr(data-badge);
        position:absolute;
        top:-6px;
        left:-6px;
        font-size: 8px;
        background:#D9D9D9;
        color:#333;
        width:12px;
        height:12px;
        text-align:center;
        line-height:12px;
        border-radius:50%;
        box-shadow:0 0 1px #333;
    }

    .do-header {
        margin: 5px 15px 12px 15px;
        font-weight: 600;
        font-size: 11px;
    }

	.dont-header {
		margin: 0 15px 12px 15px;
		font-weight: 600;
		font-size: 11px;
	}
    .motive-header {
        margin: 0;
        padding: 0;
        font-size: 9px !important;
        line-height: 11px;
        font-weight: 500;
        color: #333;
    }

    .image {
        width: 300px;
        height: 300px;
    }

    .citation-container {
        display: table;
    }

    .citation {
        padding: 10px 15px !important;
        font-style: italic;
        font-weight: 200;
        font-size: 7px;
        line-height: 10px;
        color: #333;
    }

    .card-back {
        font-family: "Inter", sans-serif;
        box-shadow: 0 1px 2px rgb(0 0 0 / 7%), 0 2px 4px rgb(0 0 0 / 7%),
            0 4px 8px rgb(0 0 0 / 7%), 0 8px 16px rgb(0 0 0 / 7%),
            0 16px 32px rgb(0 0 0 / 7%), 0 32px 64px rgb(0 0 0 / 7%);
        width: 300px !important;
        height: 500px !important;
        margin-left: auto;
        margin-right: auto;
        background-color: #ffffff;
        line-height: 1 !important;
        display: flex;
        flex-direction: column;
    }
    .vertical-middle {
        display: table-cell;
        vertical-align: middle;
    }

    .title {
        margin-top: 0;
        margin-bottom: 10px !important;
        color: #ffffff;
        font-size: 15px;
        padding: 0 15px;
        line-height: 19px !important;
        font-weight: 600 !important;
    }

    .description {
        color: #ffffff;
        padding: 0 15px;
        margin: 0;
        font-size: 11px;
        line-height: 17px !important;
        font-weight: 200 !important;
    }

    .evidence {
        padding: 0 15px;
        margin-top: 9px;
        margin-bottom: 0;
        font-size: 9px !important;
        font-weight: 200;
        line-height: 13px;
        color: #333;
        font-style: italic;   
    }
    .evidence-header {
        margin: 0;
        padding: 0 15px;
        font-size: 9px !important;
        font-weight: 600;
        color: #333;
    }
    .evidence-container {
        display: table;
        color: #000000;
        height: 170px !important;
        background-color: #EFEFEF;
    }                    
	.input {
		padding: 0 15px 15px 15px;
		margin-top: 9px;
		margin-bottom: 0;
		font-size: 9px !important;
		font-weight: 200;
		line-height: 13px;
		color: #333;
		font-style: italic;
	}
	.input-header {
		margin: 0;
		padding: 15px 15px 0 15px;
		font-size: 9px !important;
		font-weight: 600;
		color: #333;
	}
	.input-container {
		display: table;
		background-color: #EFEFEF;
		padding: 0!important;
	}
</style>
		`
	};
	
	onMount(()=> {
		$card_third = [];
		$customization_first_line = [];
		$customization_second_line = [];
		$customization_summary = [];
		$customization_original_input = [];
	})

</script>

<svelte:head>
	<title>Study</title>
	<meta name="description" content="Generate design cards" />
</svelte:head>

<section class="bg-gray-50 px-6">
	<div class="flex flex-col items-center justify-center antialiased text-gray-800 w-full">
		<div class="flex items-center">
			<div class="flex flex-col">
				{#if !isThirdLoading}
				<div class="flex mb-6 items-center">
					<div class="grow">
						<p class="font-heading grow text-lg font-medium text-gray-700">Your design cards are ready!</p>
					</div>
				</div>

				{#if $card_third.length != 0}
				<div class="text-xs flex visible justify-end mb-4">
					<div class="flex items-center">
						<button disabled='{thirdIndex == 1}' class="disabled:text-gray-300 dark:disabled:text-gray-400" on:click={() => {if (thirdIndex != 1) thirdIndex -= 1}}>
							<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="icon-xs" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
								<polyline points="15 18 9 12 15 6"></polyline>
							</svg>
						</button>
						<span class="flex-grow flex-shrink-0 tabular-nums">{thirdIndex} / {$card_third.length}</span>
						<button disabled='{thirdIndex == $card_third.length}' class="disabled:text-gray-300 dark:disabled:text-gray-400" on:click={() => {if (thirdIndex != $card_third.length) thirdIndex += 1}}>
							<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="icon-xs" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
								<polyline points="9 18 15 12 9 6"></polyline>
							</svg>
						</button>
					</div>
				</div>
				{/if}
				{/if}
				<div contenteditable="false" id="card_div" bind:innerHTML={card_htmlized} />
			</div>
			{#if isThirdLoading}
			<div class="px-6">
				<div class="flex items-center justify-center">
					<CircularProgress style="height: 50px; width: 50px;" indeterminate />
				</div>
				<p class="font-heading mt-3 text-lg font-bold text-center">Customizing cards..<br><span class="text-sm lg:text-md font-light">This may take up to 1 minute</span></p>
			</div>
			{/if}
			{#if !isThirdLoading}
			<form class="bg-white shadow-xl rounded-lg ml-4 px-4 py-3 mt-12">
				<div class="mb-4">
					<p class="mt-1 mb-3 text-sm font-medium leading-4">How do you want to customize<br>these cards for your<br>own design work?</p>
					<label for="message" class="block mt-3 mb-4 font-light text-xs text-gray-900">In a plain language, describe<br>how you would want the cards<br>to be customized:</label>
					<textarea id="message" rows="6" class="block p-2.5 w-full text-xs text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 text-xs" placeholder="ex) the persona that you're using, a design target/context you're designing for" bind:value={$customization_input}></textarea>
				</div>
				<div class="flex text-center justify-center">
					<button class="bg-slate-400 hover:bg-slate-600 text-white font-medium text-xs py-2 px-3 rounded focus:outline-none focus:shadow-outline" type="button" on:click={() => {customizationInput($customization_input);}}>
					Customize!
					</button>
				</div>
			</form>
			{/if}
		</div>
	</div>
</section>

<style>
	.float {
		position:fixed;
		bottom: 15px;
		padding: 3px 3px;
		left: auto;
		right: auto;
		border-radius: 18px;
		text-align:center;
	}
	.inner-img {
		height: 18px !important;
		margin-bottom: 4px;
		margin-right: 5px;
	}
	.float-button {
		height: 35px;
		border-radius: 15px;
		font-size: 14px;
	}
	section {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		flex: 0.6;
	}
	

	.typing-indicator {
	 width: auto;
	 padding: 6px 0px;
	 display: table;
	 position: relative;
	 animation: 2s bulge infinite ease-out;
	}
	.typing-indicator span {
		height: 8px;
		width: 8px;
		float: left;
		margin: 0 2px;
		background-color: #868686;
		display: block;
		border-radius: 50%;
		opacity: 0.4;
	}
	.typing-indicator span:nth-of-type(1) {
		animation: 1s blink infinite 0.3333s;
	}
	.typing-indicator span:nth-of-type(2) {
		animation: 1s blink infinite 0.6666s;
	}
	.typing-indicator span:nth-of-type(3) {
		animation: 1s blink infinite 0.9999s;
	}
	@keyframes blink {
		50% {
			opacity: 1;
		}
	}
	@keyframes bulge {
		50% {
			transform: scale(1.05);
		}
	}
	:global(.mdc-circular-progress__indeterminate-circle-graphic){ 
		stroke: rgb(64, 64, 64) !important
	}

    .icon {
        width: 15px;
        display: inline;
        margin-right: 5px;
        position: relative;
    }
	:global(.mdc-dialog__title) {
		font-size: 15px !important;
		padding-bottom: 0 !important;
	}
	:global(.mdc-dialog__content) {
		font-size: 13px !important;
		padding-bottom: 10px !important;
	}
	:global(.show-score) {
		font-size: 13px !important;
	}
	:global(.mdc-button__label) {
		font-size: 13px !important;
	}
</style>
