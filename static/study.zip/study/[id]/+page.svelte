<script lang='ts'>
	export let data;
    import { goto } from '$app/navigation';
	import { onMount } from 'svelte';
	import { guidelines } from '$lib/data_study.js';

	const identifier = data.id;

	$: paper_id = parseInt(identifier);

    $: urlToPdf = `/pdf/${paper_id}.pdf`;

	onMount(()=> {
		console.log(parseInt(identifier))
	})
</script>

<svelte:head>
	<title>Study</title>
	<meta name="description" content="Generate design cards" />
</svelte:head>

<section class="bg-gray-50 px-6">
	<div class="flex flex-col items-center justify-center w-full">
		<div class="grid grid-cols-2 gap-12 max-w-7xl">
			<div class="w-full h-full">
				<iframe src={urlToPdf+"#toolbar=1&navpanes=0"} class="h-[calc(100vh-7rem)] border" width="100%" loading="lazy" title="PDF-file"></iframe>
			</div>
			<div class="w-full text-center flex flex-col pb-6 items-center justify-center">
				<p class="font-heading text-lg font-medium text-gray-700 mb-4">Following is part of the paper that contains a design guideline:</p>
				<div class="bg-slate-100 shadow-xl rounded-xl border-slate-200 border-2 p-4 text-left">
					<p class="font-heading grow text-normal font-bold text-gray-700 mb-3">{@html guidelines[paper_id-1]["section"].replace(/\n/g, '<br />')}</p>
					<p class="font-heading grow text-sm text-gray-700 mb-3">{guidelines[paper_id-1]["content"]}</p>
				</div>
				<button class="bg-gray-50 border-slate-300 border-2 mt-4 shadow-xl hover:bg-gray-300 text-md text-gray-700 font-normal py-2 px-3 rounded-lg" on:click={() => {
					goto(`/study/${paper_id}/customize`);
				}}>
					<img class="w-6 inline mb-0.5" src="/favicon.png"/>
					<span class="mt-4 ml-1">Generate design cards</span>
				</button>
			</div>
		</div>
	</div>
</section>

<style>
	:global(.control) {
		margin: 0 !important
	}
</style>